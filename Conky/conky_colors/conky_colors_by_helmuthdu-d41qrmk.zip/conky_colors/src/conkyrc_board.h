#ifndef _conkyrc_board_
#define _conkyrc_board_

void conkyrc_board ();

#endif // #ifndef _conkyrc_board_
