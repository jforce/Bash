#ifndef _conkycover_
#define _conkycover_

//Create and write conkyCover
void conkycover ();

#endif // #ifndef _conkycover_
