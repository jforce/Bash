#ifndef _conkyrc_slim_
#define _conkyrc_slim_

void conkyrc_slim ();

#endif // #ifndef _conkyrc_slim_
