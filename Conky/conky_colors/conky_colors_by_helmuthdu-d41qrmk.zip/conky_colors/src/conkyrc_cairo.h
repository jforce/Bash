#ifndef _conkyrc_cairo_
#define _conkyrc_cairo_

void conkyrc_cairo ();

#endif // #ifndef _conkyrc_cairo_
