#ifndef _conkyrc_ring_
#define _conkyrc_ring_

void conkyrc_ring();

#endif // #ifndef _conkyrc_ring_
