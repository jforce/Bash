/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM /build/buildd/kompozer-0.8~b3.dfsg.1/mozilla/storage/public/mozIStorageFunction.idl
 */

#ifndef __gen_mozIStorageFunction_h__
#define __gen_mozIStorageFunction_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class mozIStorageConnection; /* forward declaration */

class mozIStorageValueArray; /* forward declaration */

class nsIArray; /* forward declaration */


/* starting interface:    mozIStorageFunction */
#define MOZISTORAGEFUNCTION_IID_STR "898d4189-7012-4ae9-a2af-435491cfa114"

#define MOZISTORAGEFUNCTION_IID \
  {0x898d4189, 0x7012, 0x4ae9, \
    { 0xa2, 0xaf, 0x43, 0x54, 0x91, 0xcf, 0xa1, 0x14 }}

/**
 * mozIStorageFunction is to be implemented by storage consumers that
 * wish to define custom storage functions, through
 * mozIStorageConnection's createFunction method.
 */
class NS_NO_VTABLE mozIStorageFunction : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(MOZISTORAGEFUNCTION_IID)

  /**
   * onFunctionCall is called when execution of a custom
   * function should occur.  There are no return values.
   * 
   * @param aNumArguments         The number of arguments
   * @param aFunctionArguments    The arguments passed in to the function
   */
  /* void onFunctionCall (in mozIStorageValueArray aFunctionArguments); */
  NS_IMETHOD OnFunctionCall(mozIStorageValueArray *aFunctionArguments) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_MOZISTORAGEFUNCTION \
  NS_IMETHOD OnFunctionCall(mozIStorageValueArray *aFunctionArguments); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_MOZISTORAGEFUNCTION(_to) \
  NS_IMETHOD OnFunctionCall(mozIStorageValueArray *aFunctionArguments) { return _to OnFunctionCall(aFunctionArguments); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_MOZISTORAGEFUNCTION(_to) \
  NS_IMETHOD OnFunctionCall(mozIStorageValueArray *aFunctionArguments) { return !_to ? NS_ERROR_NULL_POINTER : _to->OnFunctionCall(aFunctionArguments); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public mozIStorageFunction
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_MOZISTORAGEFUNCTION

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, mozIStorageFunction)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* void onFunctionCall (in mozIStorageValueArray aFunctionArguments); */
NS_IMETHODIMP _MYCLASS_::OnFunctionCall(mozIStorageValueArray *aFunctionArguments)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_mozIStorageFunction_h__ */
