/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM /build/buildd/kompozer-0.8~b3.dfsg.1/mozilla/storage/public/mozIStorageStatement.idl
 */

#ifndef __gen_mozIStorageStatement_h__
#define __gen_mozIStorageStatement_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

#ifndef __gen_mozIStorageValueArray_h__
#include "mozIStorageValueArray.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif
class mozIStorageConnection; /* forward declaration */

class mozIStorageDataSet; /* forward declaration */

class nsISimpleEnumerator; /* forward declaration */


/* starting interface:    mozIStorageStatement */
#define MOZISTORAGESTATEMENT_IID_STR "1f39bc95-090d-40a5-9dee-6d5a591e48bf"

#define MOZISTORAGESTATEMENT_IID \
  {0x1f39bc95, 0x090d, 0x40a5, \
    { 0x9d, 0xee, 0x6d, 0x5a, 0x59, 0x1e, 0x48, 0xbf }}

class NS_NO_VTABLE mozIStorageStatement : public mozIStorageValueArray {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(MOZISTORAGESTATEMENT_IID)

  /**
   * Initialize this query with the given SQL statement.
   *
   */
  /* void initialize (in mozIStorageConnection aDBConnection, in AUTF8String aSQLStatement); */
  NS_IMETHOD Initialize(mozIStorageConnection *aDBConnection, const nsACString & aSQLStatement) = 0;

  /**
   * Create a clone of this statement, by initializing a new statement
   * with the same connection and same SQL statement as this one.  It
   * does not preserve statement state; that is, if a statement is
   * being executed when it is cloned, the new statement will not be
   * executing.
   */
  /* mozIStorageStatement clone (); */
  NS_IMETHOD Clone(mozIStorageStatement **_retval) = 0;

  /* readonly attribute unsigned long parameterCount; */
  NS_IMETHOD GetParameterCount(PRUint32 *aParameterCount) = 0;

  /**
   * Name of nth parameter, if given
   */
  /* AUTF8String getParameterName (in unsigned long aParamIndex); */
  NS_IMETHOD GetParameterName(PRUint32 aParamIndex, nsACString & _retval) = 0;

  /**
   * All indexes of a named parameter, if it's specified more than once
   */
  /* void getParameterIndexes (in AUTF8String aParameterName, out unsigned long aCount, [array, size_is (aCount), retval] out unsigned long aIndexes); */
  NS_IMETHOD GetParameterIndexes(const nsACString & aParameterName, PRUint32 *aCount, PRUint32 **aIndexes) = 0;

  /**
   * Number of columns returned
   */
  /* readonly attribute unsigned long columnCount; */
  NS_IMETHOD GetColumnCount(PRUint32 *aColumnCount) = 0;

  /**
   * Name of nth column
   */
  /* AUTF8String getColumnName (in unsigned long aColumnIndex); */
  NS_IMETHOD GetColumnName(PRUint32 aColumnIndex, nsACString & _retval) = 0;

  /**
   * Reset parameters/statement execution
   */
  /* void reset (); */
  NS_IMETHOD Reset(void) = 0;

  /**
   * Bind the given value to the parameter at aParamIndex.
   */
  /* void bindUTF8StringParameter (in unsigned long aParamIndex, in AUTF8String aValue); */
  NS_IMETHOD BindUTF8StringParameter(PRUint32 aParamIndex, const nsACString & aValue) = 0;

  /* void bindStringParameter (in unsigned long aParamIndex, in AString aValue); */
  NS_IMETHOD BindStringParameter(PRUint32 aParamIndex, const nsAString & aValue) = 0;

  /* void bindDoubleParameter (in unsigned long aParamIndex, in double aValue); */
  NS_IMETHOD BindDoubleParameter(PRUint32 aParamIndex, double aValue) = 0;

  /* void bindInt32Parameter (in unsigned long aParamIndex, in long aValue); */
  NS_IMETHOD BindInt32Parameter(PRUint32 aParamIndex, PRInt32 aValue) = 0;

  /* void bindInt64Parameter (in unsigned long aParamIndex, in long long aValue); */
  NS_IMETHOD BindInt64Parameter(PRUint32 aParamIndex, PRInt64 aValue) = 0;

  /* void bindNullParameter (in unsigned long aParamIndex); */
  NS_IMETHOD BindNullParameter(PRUint32 aParamIndex) = 0;

  /* void bindBlobParameter (in unsigned long aParamIndex, [array, size_is (aValueSize), const] in octet aValue, in unsigned long aValueSize); */
  NS_IMETHOD BindBlobParameter(PRUint32 aParamIndex, const PRUint8 *aValue, PRUint32 aValueSize) = 0;

  /**
   * Execute the query, ignoring any results.  This is accomplished by
   * calling step() once, and then calling reset().
   *
   * Error and last insert info, etc. are available from
   * the mozStorageConnection.
   */
  /* void execute (); */
  NS_IMETHOD Execute(void) = 0;

  /**
   * Execute a query, using any currently-bound parameters.  Reset
   * must be called on the statement after the last call of
   * executeStep.
   *
   * @returns a boolean indicating whether there are more rows or not;
   * row data may be accessed using mozIStorageValueArray methods on
   * the statement.
   *
   */
  /* boolean executeStep (); */
  NS_IMETHOD ExecuteStep(PRBool *_retval) = 0;

  /**
   * The current state.  Row getters are only valid while
   * the statement is in the "executing" state.
   */
  enum { MOZ_STORAGE_STATEMENT_INVALID = 0 };

  enum { MOZ_STORAGE_STATEMENT_READY = 1 };

  enum { MOZ_STORAGE_STATEMENT_EXECUTING = 2 };

  /* readonly attribute long state; */
  NS_IMETHOD GetState(PRInt32 *aState) = 0;

  /* [noscript, notxpcom] sqlite3stmtptr getNativeStatementPointer (); */
  NS_IMETHOD_(struct sqlite3_stmt *) GetNativeStatementPointer(void) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_MOZISTORAGESTATEMENT \
  NS_IMETHOD Initialize(mozIStorageConnection *aDBConnection, const nsACString & aSQLStatement); \
  NS_IMETHOD Clone(mozIStorageStatement **_retval); \
  NS_IMETHOD GetParameterCount(PRUint32 *aParameterCount); \
  NS_IMETHOD GetParameterName(PRUint32 aParamIndex, nsACString & _retval); \
  NS_IMETHOD GetParameterIndexes(const nsACString & aParameterName, PRUint32 *aCount, PRUint32 **aIndexes); \
  NS_IMETHOD GetColumnCount(PRUint32 *aColumnCount); \
  NS_IMETHOD GetColumnName(PRUint32 aColumnIndex, nsACString & _retval); \
  NS_IMETHOD Reset(void); \
  NS_IMETHOD BindUTF8StringParameter(PRUint32 aParamIndex, const nsACString & aValue); \
  NS_IMETHOD BindStringParameter(PRUint32 aParamIndex, const nsAString & aValue); \
  NS_IMETHOD BindDoubleParameter(PRUint32 aParamIndex, double aValue); \
  NS_IMETHOD BindInt32Parameter(PRUint32 aParamIndex, PRInt32 aValue); \
  NS_IMETHOD BindInt64Parameter(PRUint32 aParamIndex, PRInt64 aValue); \
  NS_IMETHOD BindNullParameter(PRUint32 aParamIndex); \
  NS_IMETHOD BindBlobParameter(PRUint32 aParamIndex, const PRUint8 *aValue, PRUint32 aValueSize); \
  NS_IMETHOD Execute(void); \
  NS_IMETHOD ExecuteStep(PRBool *_retval); \
  NS_IMETHOD GetState(PRInt32 *aState); \
  NS_IMETHOD_(struct sqlite3_stmt *) GetNativeStatementPointer(void); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_MOZISTORAGESTATEMENT(_to) \
  NS_IMETHOD Initialize(mozIStorageConnection *aDBConnection, const nsACString & aSQLStatement) { return _to Initialize(aDBConnection, aSQLStatement); } \
  NS_IMETHOD Clone(mozIStorageStatement **_retval) { return _to Clone(_retval); } \
  NS_IMETHOD GetParameterCount(PRUint32 *aParameterCount) { return _to GetParameterCount(aParameterCount); } \
  NS_IMETHOD GetParameterName(PRUint32 aParamIndex, nsACString & _retval) { return _to GetParameterName(aParamIndex, _retval); } \
  NS_IMETHOD GetParameterIndexes(const nsACString & aParameterName, PRUint32 *aCount, PRUint32 **aIndexes) { return _to GetParameterIndexes(aParameterName, aCount, aIndexes); } \
  NS_IMETHOD GetColumnCount(PRUint32 *aColumnCount) { return _to GetColumnCount(aColumnCount); } \
  NS_IMETHOD GetColumnName(PRUint32 aColumnIndex, nsACString & _retval) { return _to GetColumnName(aColumnIndex, _retval); } \
  NS_IMETHOD Reset(void) { return _to Reset(); } \
  NS_IMETHOD BindUTF8StringParameter(PRUint32 aParamIndex, const nsACString & aValue) { return _to BindUTF8StringParameter(aParamIndex, aValue); } \
  NS_IMETHOD BindStringParameter(PRUint32 aParamIndex, const nsAString & aValue) { return _to BindStringParameter(aParamIndex, aValue); } \
  NS_IMETHOD BindDoubleParameter(PRUint32 aParamIndex, double aValue) { return _to BindDoubleParameter(aParamIndex, aValue); } \
  NS_IMETHOD BindInt32Parameter(PRUint32 aParamIndex, PRInt32 aValue) { return _to BindInt32Parameter(aParamIndex, aValue); } \
  NS_IMETHOD BindInt64Parameter(PRUint32 aParamIndex, PRInt64 aValue) { return _to BindInt64Parameter(aParamIndex, aValue); } \
  NS_IMETHOD BindNullParameter(PRUint32 aParamIndex) { return _to BindNullParameter(aParamIndex); } \
  NS_IMETHOD BindBlobParameter(PRUint32 aParamIndex, const PRUint8 *aValue, PRUint32 aValueSize) { return _to BindBlobParameter(aParamIndex, aValue, aValueSize); } \
  NS_IMETHOD Execute(void) { return _to Execute(); } \
  NS_IMETHOD ExecuteStep(PRBool *_retval) { return _to ExecuteStep(_retval); } \
  NS_IMETHOD GetState(PRInt32 *aState) { return _to GetState(aState); } \
  NS_IMETHOD_(struct sqlite3_stmt *) GetNativeStatementPointer(void) { return _to GetNativeStatementPointer(); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_MOZISTORAGESTATEMENT(_to) \
  NS_IMETHOD Initialize(mozIStorageConnection *aDBConnection, const nsACString & aSQLStatement) { return !_to ? NS_ERROR_NULL_POINTER : _to->Initialize(aDBConnection, aSQLStatement); } \
  NS_IMETHOD Clone(mozIStorageStatement **_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->Clone(_retval); } \
  NS_IMETHOD GetParameterCount(PRUint32 *aParameterCount) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetParameterCount(aParameterCount); } \
  NS_IMETHOD GetParameterName(PRUint32 aParamIndex, nsACString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetParameterName(aParamIndex, _retval); } \
  NS_IMETHOD GetParameterIndexes(const nsACString & aParameterName, PRUint32 *aCount, PRUint32 **aIndexes) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetParameterIndexes(aParameterName, aCount, aIndexes); } \
  NS_IMETHOD GetColumnCount(PRUint32 *aColumnCount) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetColumnCount(aColumnCount); } \
  NS_IMETHOD GetColumnName(PRUint32 aColumnIndex, nsACString & _retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetColumnName(aColumnIndex, _retval); } \
  NS_IMETHOD Reset(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Reset(); } \
  NS_IMETHOD BindUTF8StringParameter(PRUint32 aParamIndex, const nsACString & aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindUTF8StringParameter(aParamIndex, aValue); } \
  NS_IMETHOD BindStringParameter(PRUint32 aParamIndex, const nsAString & aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindStringParameter(aParamIndex, aValue); } \
  NS_IMETHOD BindDoubleParameter(PRUint32 aParamIndex, double aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindDoubleParameter(aParamIndex, aValue); } \
  NS_IMETHOD BindInt32Parameter(PRUint32 aParamIndex, PRInt32 aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindInt32Parameter(aParamIndex, aValue); } \
  NS_IMETHOD BindInt64Parameter(PRUint32 aParamIndex, PRInt64 aValue) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindInt64Parameter(aParamIndex, aValue); } \
  NS_IMETHOD BindNullParameter(PRUint32 aParamIndex) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindNullParameter(aParamIndex); } \
  NS_IMETHOD BindBlobParameter(PRUint32 aParamIndex, const PRUint8 *aValue, PRUint32 aValueSize) { return !_to ? NS_ERROR_NULL_POINTER : _to->BindBlobParameter(aParamIndex, aValue, aValueSize); } \
  NS_IMETHOD Execute(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->Execute(); } \
  NS_IMETHOD ExecuteStep(PRBool *_retval) { return !_to ? NS_ERROR_NULL_POINTER : _to->ExecuteStep(_retval); } \
  NS_IMETHOD GetState(PRInt32 *aState) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetState(aState); } \
  NS_IMETHOD_(struct sqlite3_stmt *) GetNativeStatementPointer(void) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetNativeStatementPointer(); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class _MYCLASS_ : public mozIStorageStatement
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_MOZISTORAGESTATEMENT

  _MYCLASS_();

private:
  ~_MYCLASS_();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(_MYCLASS_, mozIStorageStatement)

_MYCLASS_::_MYCLASS_()
{
  /* member initializers and constructor code */
}

_MYCLASS_::~_MYCLASS_()
{
  /* destructor code */
}

/* void initialize (in mozIStorageConnection aDBConnection, in AUTF8String aSQLStatement); */
NS_IMETHODIMP _MYCLASS_::Initialize(mozIStorageConnection *aDBConnection, const nsACString & aSQLStatement)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* mozIStorageStatement clone (); */
NS_IMETHODIMP _MYCLASS_::Clone(mozIStorageStatement **_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute unsigned long parameterCount; */
NS_IMETHODIMP _MYCLASS_::GetParameterCount(PRUint32 *aParameterCount)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* AUTF8String getParameterName (in unsigned long aParamIndex); */
NS_IMETHODIMP _MYCLASS_::GetParameterName(PRUint32 aParamIndex, nsACString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void getParameterIndexes (in AUTF8String aParameterName, out unsigned long aCount, [array, size_is (aCount), retval] out unsigned long aIndexes); */
NS_IMETHODIMP _MYCLASS_::GetParameterIndexes(const nsACString & aParameterName, PRUint32 *aCount, PRUint32 **aIndexes)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute unsigned long columnCount; */
NS_IMETHODIMP _MYCLASS_::GetColumnCount(PRUint32 *aColumnCount)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* AUTF8String getColumnName (in unsigned long aColumnIndex); */
NS_IMETHODIMP _MYCLASS_::GetColumnName(PRUint32 aColumnIndex, nsACString & _retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void reset (); */
NS_IMETHODIMP _MYCLASS_::Reset()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindUTF8StringParameter (in unsigned long aParamIndex, in AUTF8String aValue); */
NS_IMETHODIMP _MYCLASS_::BindUTF8StringParameter(PRUint32 aParamIndex, const nsACString & aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindStringParameter (in unsigned long aParamIndex, in AString aValue); */
NS_IMETHODIMP _MYCLASS_::BindStringParameter(PRUint32 aParamIndex, const nsAString & aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindDoubleParameter (in unsigned long aParamIndex, in double aValue); */
NS_IMETHODIMP _MYCLASS_::BindDoubleParameter(PRUint32 aParamIndex, double aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindInt32Parameter (in unsigned long aParamIndex, in long aValue); */
NS_IMETHODIMP _MYCLASS_::BindInt32Parameter(PRUint32 aParamIndex, PRInt32 aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindInt64Parameter (in unsigned long aParamIndex, in long long aValue); */
NS_IMETHODIMP _MYCLASS_::BindInt64Parameter(PRUint32 aParamIndex, PRInt64 aValue)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindNullParameter (in unsigned long aParamIndex); */
NS_IMETHODIMP _MYCLASS_::BindNullParameter(PRUint32 aParamIndex)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void bindBlobParameter (in unsigned long aParamIndex, [array, size_is (aValueSize), const] in octet aValue, in unsigned long aValueSize); */
NS_IMETHODIMP _MYCLASS_::BindBlobParameter(PRUint32 aParamIndex, const PRUint8 *aValue, PRUint32 aValueSize)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* void execute (); */
NS_IMETHODIMP _MYCLASS_::Execute()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* boolean executeStep (); */
NS_IMETHODIMP _MYCLASS_::ExecuteStep(PRBool *_retval)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* readonly attribute long state; */
NS_IMETHODIMP _MYCLASS_::GetState(PRInt32 *aState)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* [noscript, notxpcom] sqlite3stmtptr getNativeStatementPointer (); */
NS_IMETHODIMP_(struct sqlite3_stmt *) _MYCLASS_::GetNativeStatementPointer()
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_mozIStorageStatement_h__ */
