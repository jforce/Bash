#/bin/bash

IP=$1

function bar () {
valor=$1
resolucao=$2

for i in `seq $valor`
do
	if [ `expr $i % $resolucao` -eq 0 ]
	then
	echo -n "|"
	fi
done
echo " $1"
}

packetlost=""
> data.txt

for i in `seq 10`
do
	packetlost=` ping -c4 $IP | grep -o [0-9]*[0-9]% | sed -e 's/%//g' `
	#bar $packetlost 10
	tempo=` date +"%T" `
	echo $tempo $packetlost
	echo $tempo $packetlost >> data.txt
done

/usr/bin/gnuplot ./data.gp

display -update 1 ./data.png &


