#!/usr/bin/env bash
#! autor: cfjrocha@gmail.com
#! 2008

function remover {
clear
echo "  ____________________________________________________"
echo "||          Removendo Ficheiros Desnecessários        ||"
echo "||____________________________________________________||"
echo
echo "   Removendo o Ficheiro Thumbs.db da maquina"
sudo find /media/ -name Thumbs.db -exec rm -f {} \;
echo "   Removendo o Ficheiro desktop.ini da maquina"
sudo find /media/ -name desktop.ini -exec rm -f {} \;
echo "   Removendo o Ficheiro .DS_Store da maquina"
sudo find /media/ -name .DS_Store -exec rm -f {} \;
echo "   Removendo o Ficheiro ZbThumbnail.info da maquina"
sudo find /media/ -name ZbThumbnail.info -exec rm -f {} \;
echo "   Removendo o Ficheiro Picasa.ini da maquina"
sudo find /media/ -name Picasa.ini -exec rm -f {} \;
echo "   Removendo o Ficheiro ehthumbs_vista.db da maquina"
sudo find /media/ -name ehthumbs_vista.db -exec rm -f {} \;
echo "   Removendo o Ficheiro ehthumbs_vista.db:encryptable da maquina"
sudo find /media/ -name ehthumbs_vista.db:encryptable -exec rm -f {} \;
echo "   Removendo o Ficheiro ehthumbs.db da maquina"
sudo find /media/ -name ehthumbs.db -exec rm -f {} \;
echo "   Removendo o Ficheiro ehthumbs.db:encryptable da maquina"
sudo find /media/ -name ehthumbs.db:encryptable -exec rm -f {} \;
echo "   Remoção de Ficheiros da maquina concluida!"
}

function copia {
clear
echo "  ____________________________________________________"
echo "||          Realizando copias de segurança            ||"
echo "||____________________________________________________||"
echo
echo "   Realizando Backup das Fotos para usbDisk02..."
echo $(date) >> /home/francisco/log_foto.txt
sudo rsync -r -t -p -o -g -v /mnt/hd3/AsMinhasFotos/ /media/usbDisk02/Backup/AsMinhasFotos/ >> /home/francisco/log_foto.txt
echo "   Backup das fotos concluido!"
echo "   Realizando Backup dos Videos para usbDisk02..."
echo $(date) >> /home/francisco/log_video.txt
sudo rsync -r -t -p -o -g -v /mnt/hd2/VideosDeFamilia/ /media/usbDisk02/Backup/VideosDeFamilia/ >> /home/francisco/log_video.txt
echo "   Backup dos Videos concluido!"
}

function hd1Check {
clear
echo "  ____________________________________________________"
echo "||               File Check do hd1 ...                ||"
echo "||____________________________________________________||"
echo
#! killall -9 java
#! killall -9 amule
#! sleep 10
sudo umount /mnt/hd1
sudo /sbin/e2fsck -f -y -v /dev/disk/by-id/scsi-SATA_MAXTOR_STM33208_9RV0363L-part3
sudo mount /mnt/hd1
echo "   File Check do hd1 concluido!"
#! azureus>/dev/null&
#! amule>/dev/null&
#! sleep 10
}

function hd2Check {
clear
echo "  ____________________________________________________"
echo "||               File Check do hd2 ...                ||"
echo "||____________________________________________________||"
echo
sudo umount /mnt/hd2
sudo /sbin/e2fsck -f -y -v /dev/disk/by-id/scsi-SATA_ST3750640A_5QD0G7K3-part1
sudo mount /mnt/hd2
echo "   File Check do hd2 concluido!"
}

function hd3Check {
clear
echo "  ____________________________________________________"
echo "||               File Check do hd3 ...                ||"
echo "||____________________________________________________||"
echo
sudo umount /mnt/hd3
sudo /sbin/e2fsck -f -y -v /dev/disk/by-id/scsi-SATA_Maxtor_6L250R0_L606XYEH-part1
sudo mount /mnt/hd3
echo "   File Check do hd3 concluido!"
}

function hd4Check {
clear
echo "  ____________________________________________________"
echo "||               File Check do hd4 ...                ||"
echo "||____________________________________________________||"
echo
sudo umount /mnt/hd4
sudo /sbin/e2fsck -f -y -v /dev/disk/by-id/scsi-SATA_ST3750640AV_5QD5FV5P-part1
sudo mount /mnt/hd4
echo "   File Check do hd3 concluido!"
}

function hd5Check {
clear
echo "  ____________________________________________________"
echo "||               File Check do hd5 ...                ||"
echo "||____________________________________________________||"
echo
sudo umount /mnt/hd5
sudo /sbin/e2fsck -f -y -v /dev/disk/by-id/scsi-SATA_ST3500841AS_3PM13T7M-part1
sudo mount /mnt/hd5
echo "   File Check do hd5 concluido!"
}

function hd6Check {
clear
echo "  ____________________________________________________"
echo "||               File Check do hd6 ...                ||"
echo "||____________________________________________________||"
echo
sudo umount /mnt/hd6
sudo /sbin/e2fsck -f -y -v /dev/disk/by-id/scsi-SATA_WDC_WD5000AAJS-_WD-WMASY0025881-part1
sudo mount /mnt/hd6
echo "   File Check do hd6 concluido!"
}


function actualiza {
clear
echo "  ____________________________________________________"
echo "||          Actualizando o comando Locate             ||"
echo "||____________________________________________________||"
echo
sudo updatedb
echo "   Actualização o comando Locate concluida!"
}

function atrib755 {
clear
echo "  ____________________________________________________"
echo "||         Alterando permissões para 755...           ||"
echo "||____________________________________________________||"
echo
echo "Alterando permissões para 755..."
sudo chmod -R 755 /media/
sudo chmod -R 750 "/media/dskE1000/zZz"
echo "Alterando dono e grupo para francisco..."
sudo chown -R francisco:francisco /media/
echo "Alteração de permissões concluida!"
}

function atrib777 {
clear
echo "  ____________________________________________________"
echo "||         Alterando permissões para 777...           ||"
echo "||____________________________________________________||"
echo
echo "Alterando permissões para 777..."
sudo chmod -R 777 /media/
sudo chmod -R 770 "/media/dskE1000/zZz"
echo "Alterando dono e grupo para francisco..."
sudo chown -R francisco:francisco /media/
echo "Alteração de permissões concluida!"
}

function zZz {
clear
echo "  ____________________________________________________"
echo "||          Pasta zZz a ser desbloqueada...           ||"
echo "||____________________________________________________||"
echo
echo "Alterando permissões para 777..."
sudo chmod -R 777 "/media/dskE1000/zZz"
echo "Alterando dono e grupo para francisco..."
sudo chown -R francisco:users "/media/dskE1000/zZz"
echo "Alteração de permissões concluida!"
read -p "Precione alguma tecla para continuar"
echo "Bloqueando a pasta zZz ..."
sudo chmod -R 770 "/media/dskE1000/zZz"
echo "Alteração de permissões concluida!"
}

function discosStdby {
clear
echo "  ____________________________________________________"
echo "||          Colocando discos em Stand by...           ||"
echo "||____________________________________________________||"
echo
sudo hdparm -y /dev/sda
sudo hdparm -y /dev/sdb
sudo hdparm -y /dev/sdc
sudo hdparm -y /dev/sdd
sudo hdparm -y /dev/sde
echo " Tarefa concluída !"
}

function discosSleep {
clear
echo "  ____________________________________________________"
echo "||          Colocando discos em Sleep ...             ||"
echo "||____________________________________________________||"
echo
sudo hdparm -Y /dev/sda
sudo hdparm -Y /dev/sdb
sudo hdparm -Y /dev/sdc
sudo hdparm -Y /dev/sdd
sudo hdparm -Y /dev/sde
echo " Tarefa concluída !"
}


#######################################################
#                      MENUS                          #
#######################################################

function menuDesliga {
let "loopd=0"
while test $loopd == 0
do
clear
echo "    _____________________________________________________________"
echo "  ||                           MENU DESLIGAR                     ||"
echo "  ||_____________________________________________________________||"
echo "  ||                                                             ||"
echo "  ||                                                             ||"
echo "  ||   [7] Alterar atributos dos ficheiros para 777 e desligar   ||"
echo "  ||   [C] Realizar copia de segurança e desligar                ||"
echo "  ||   [D] Verificar integridades dos discos e desligar          ||"
echo "  ||   [R] Remover ficheiros indesejados e desligar              ||"
echo "  ||   [T] Fazer todas as anteriores e desligar                  ||"
echo "  ||                                                             ||"
echo "  ||   [M] Menu Principal                                        ||"
echo "  ||_____________________________________________________________||"
echo "     ==========================================================="
echo
echo "Opção? " && read opcao
case $opcao in m|M)
let "loopd=1"
esac
case $opcao in 7)
atrib777
init 0
esac
case $opcao in c|C)
copia
init 0
esac
case $opcao in d|D)
hd1Check
hd2Check
hd3Check
hd4Check
hd5Check
hd6Check
init 0
esac
case $opcao in r|R)
remover
init 0
esac
case $opcao in t|T)
remover
atrib777
copia
hd1Check
hd2Check
hd3Check
hd4Check
hd5Check
hd6Check
init 0
esac

done
}

function menuCheck {
let "loopc=0"
while test $loopc == 0
do
clear
echo "    ____________________________________________________"
echo "  ||                  MENU VERIFICAR                    ||"
echo "  ||____________________________________________________||"
echo "  ||                                                    ||"
echo "  ||                                                    ||"
echo "  ||   [1] Verificar integridade do HD1                 ||"
echo "  ||   [2] Verificar integridade do HD2                 ||"
echo "  ||   [3] Verificar integridade do HD3                 ||"
echo "  ||   [4] Verificar integridade do HD4                 ||"
echo "  ||   [5] Verificar integridade do HD5                 ||"
echo "  ||   [6] Verificar integridade do HD6 (inactivo)      ||"
echo "  ||   [T] Verificar integridade de todos               ||"
echo "  ||   [S] Colocar os discos em Stand by                ||"
echo "  ||   [D] Colocar os discos em Sleep                   ||"
echo "  ||                                                    ||"
echo "  ||   [M] Menu Principal                               ||"
echo "  ||____________________________________________________||"
echo "     =================================================="
echo
echo "Opção? " && read opcao
case $opcao in m|M)
let "loopc=1"
esac
case $opcao in 1)
hd1Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in 2)
hd2Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in 3)
hd3Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in 4)
hd4Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in 5)
hd5Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in 6)
hd6Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in t|T)
hd1Check
hd2Check
hd3Check
hd4Check
hd5Check
hd6Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in s|S)
discosStdby
read -p "Precione alguma tecla para continuar"
esac
case $opcao in d|D)
discosSleep
read -p "Precione alguma tecla para continuar"
esac

done
}

function menuAtrib {
let "loopa=0"
while test $loopa == 0
do
clear
echo "    ____________________________________________________"
echo "  ||                  MENU ATRIBUTOS                    ||"
echo "  ||____________________________________________________||"
echo "  ||                                                    ||"
echo "  ||                                                    ||"
echo "  ||   [7] Alterar atributos dos ficheiros para 777     ||"
echo "  ||   [5] Alterar atributos dos ficheiros para 755     ||"
echo "  ||   [Z] Desbloquear zZz                              ||"
echo "  ||                                                    ||"
echo "  ||   [M] Menu Principal                               ||"
echo "  ||____________________________________________________||"
echo "     =================================================="
echo
echo "Opção? " && read opcao
case $opcao in m|M)
let "loopa=1"
esac
case $opcao in 7)
atrib777
read -p "Precione alguma tecla para continuar"
esac
case $opcao in 5)
atrib755
read -p "Precione alguma tecla para continuar"
esac
case $opcao in z|Z)
zZz
read -p "Precione alguma tecla para continuar"
esac
done
}

let "loop=0"
while test $loop == 0
do
clear
echo "    ____________________________________________________"
echo "  ||                  MENU PRINCIPAL                    ||"
echo "  ||____________________________________________________||"
echo "  ||                                                    ||"
echo "  ||                                                    ||"
echo "  ||   [R] Remover Ficheiros indesejados                ||"
echo "  ||   [A] Alterar atributos dos ficheiros              ||"
echo "  ||   [C] Realizar copia de segurança                  ||"
echo "  ||   [S] Storage                                      ||"
echo "  ||   [L] Actualizar db do comando locate              ||"
echo "  ||   [T] Tudo (com Atributos 777)                     ||"
echo "  ||   [D] Desligar                                     ||"
echo "  ||                                                    ||"
echo "  ||                                                    ||"
echo "  ||   Pressione [Q] para Sair                          ||"
echo "  ||____________________________________________________||"
echo "     =================================================="
echo
echo "Opção? " && read opcao
case $opcao in q|Q)
let "loop=1"
esac
case $opcao in r|R)
remover
read -p "Precione alguma tecla para continuar"
esac
case $opcao in a|A)
menuAtrib
esac
case $opcao in c|C)
copia
read -p "Precione alguma tecla para continuar"
esac
case $opcao in s|S)
menuCheck
esac
case $opcao in l|L)
actualiza
esac
case $opcao in t|T)
remover
atrib777
copia
hd1Check
hd2Check
hd3Check
hd4Check
hd5Check
hd6Check
read -p "Precione alguma tecla para continuar"
esac
case $opcao in d|D)
menuDesliga
esac
done

fi


