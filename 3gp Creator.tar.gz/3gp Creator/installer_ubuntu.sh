#!/bin/sh
sudo aptitude purge ffmpeg
sudo ./install-ffmpeg
sudo apt-get install mono gtk-sharp gtk-sharp2
echo ""
echo "Done, you can now run 3gpCreator by typping ./3gpCreator.exe"
