// This code is derivdeed from the example code in Section 4.8 
// Mono: A Developer's Notebook (ISBN 0-596-00792-2) Published by O'Reilly
// Written by Edd Dumbill & Neil M. Bornstein
// http://www.oreilly.com/catalog/monoadn/
//
// jpoa (at) student (.) dei (.) uc (.) pt

using System;
using System.Text.RegularExpressions;
using Gtk;
using Gdk;

class MainClass {
    // the media types we'll accept
    private static Gtk.TargetEntry [  ] target_table = 
	new TargetEntry [  ] {
	    new TargetEntry ("text/uri-list", 0, 0),
	};

    private static Gdk.Pixbuf video;
    private static Gtk.RadioButton flv;
    private static Gtk.RadioButton avi_mpeg;
	
    public static void Main(string[  ] args)
    {
	Application.Init ( );
	video = new Pixbuf (null, "video.png");
	Gtk.Window w = new Gtk.Window ("3gp Creator");
	w.DeleteEvent += Window_Delete;
    
	Gtk.Frame prefFrame = new Gtk.Frame("Preferences");
	
	HBox h = new HBox ( );
	h.BorderWidth = 6;
	h.Spacing = 6;

	HBox h2 = new HBox ( );
	h2.BorderWidth = 6;
	h2.Spacing = 6;
	
	VBox v1 = new VBox();
	v1.BorderWidth = 6;
	v1.Spacing = 6;

	VBox v2 = new VBox();
	v2.BorderWidth = 6;
	v2.Spacing = 6;

	VBox v3 = new VBox();
	v3.BorderWidth = 6;
	v3.Spacing = 6;
	

	Gtk.EventBox image = new Gtk.EventBox ( );
	image.Add (new Gtk.Image (video));
	h.Add (image);

	Gtk.Label label = new Gtk.Label ("Drop Video Here\nTo Convert");
	h.Add (label);
	
	flv = new Gtk.RadioButton ("flv to 3gp");
	v2.Add(flv);
	
	avi_mpeg = new Gtk.RadioButton(flv, "avi/mpeg to 3gp");
	v2.Add(avi_mpeg);
	
	v1.Add(h);
	prefFrame.Add(h2);
	h2.Add(v2);
	h2.Add(v3);
	v1.Add(prefFrame);

	w.Add (v1);
	w.ShowAll ( );

	
	// set up label as a drop target
	Gtk.Drag.DestSet (label, DestDefaults.All, target_table,
			  Gdk.DragAction.Copy);
	label.DragDataReceived += Data_Received;

	Application.Run ( );
    }
  
    static void Data_Received (object o, DragDataReceivedArgs args)
    {
	bool success = false;
	string data = System.Text.Encoding.UTF8.GetString (
							   args.SelectionData.Data);
	
	switch (args.Info) {
	case 0:  // uri-list
	    string [  ] uri_list = Regex.Split (data, "\r\n");
	    foreach (string u in uri_list) {
		if (u.Length > 0)
		    {
			

			if(flv.Active){
	    			
				String filename = u.Substring(7);
				String outputfilename = filename.Substring(filename.LastIndexOf("/")+1);
				String outputpath = filename.Substring(0,filename.LastIndexOf("/"));
				System.Console.WriteLine("Got filename {0}", filename);
				System.Diagnostics.Process proc = new System.Diagnostics.Process();
				proc.EnableRaisingEvents = false;
				proc.StartInfo.FileName = "ffmpeg";
				proc.StartInfo.Arguments = " -i " + + filename + " -ab 56 -ar 22050 -b 500  -s 320x240 " + outputpath + "/" + outputfilename.Substring(0,outputfilename.LastIndexOf(".")) + ".mpg";
				Console.WriteLine("Arguments are " + proc.StartInfo.Arguments);
				proc.Start();
				proc.WaitForExit();

				if(0 != proc.ExitCode)
				Console.WriteLine("Error");


				proc.EnableRaisingEvents = false;
				proc.StartInfo.FileName = "ffmpeg";
				proc.StartInfo.Arguments = " -i " + + outputfilename.Substring(0,outputfilename.LastIndexOf(".")) + ".mpg" + " -acodec amr_nb -ar 8000 -ac 1 -ab 32 -vcodec h263 -s qcif -r 10 " + outputpath + "/" + outputfilename.Substring(0,outputfilename.LastIndexOf(".")) + ".3gp";
				proc.Start();
				proc.WaitForExit();
		
				if(0 != proc.ExitCode)
				Console.WriteLine("Error");

				proc.EnableRaisingEvents = false;
				proc.StartInfo.FileName = "rm";
				proc.StartInfo.Arguments = outputfilename.Substring(0,outputfilename.LastIndexOf(".")) + ".mpg";
				proc.Start();
				proc.WaitForExit();
		
				System.Console.WriteLine ("Done.");

				if(0 != proc.ExitCode)
				Console.WriteLine("Error");

			}else{
				String filename = u.Substring(7);
				String outputfilename = filename.Substring(filename.LastIndexOf("/")+1);
				String outputpath = filename.Substring(0,filename.LastIndexOf("/"));
				System.Diagnostics.Process proc = new System.Diagnostics.Process();
				proc.EnableRaisingEvents = false;
				proc.StartInfo.FileName = "ffmpeg";
				proc.StartInfo.Arguments = " -i " + + filename + " -acodec amr_nb -ar 8000 -ac 1 -ab 32 -vcodec h263 -s qcif -r 10 " + outputpath + "/" + outputfilename.Substring(0,outputfilename.LastIndexOf(".")) + ".3gp";
				proc.Start();
				proc.WaitForExit();
		
				System.Console.WriteLine ("Done.");

				if(0 != proc.ExitCode)
				Console.WriteLine("Error");
			}


			
	      
		    }
	    }
	    success = true;
	    break;
	}
    
	Gtk.Drag.Finish (args.Context, success, false, args.Time);
    }

    
    static void Window_Delete (object o, DeleteEventArgs args)
    {
	Application.Quit ( );
    }
}
