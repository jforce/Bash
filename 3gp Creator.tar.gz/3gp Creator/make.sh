#!/bin/sh
mcs 3gpCreator.cs -pkg:gtk-sharp -resource:video.png,video.png -out:3gpCreator.exe
echo ""
echo "Done. Just type ./3gpCreator.exe to execute."
